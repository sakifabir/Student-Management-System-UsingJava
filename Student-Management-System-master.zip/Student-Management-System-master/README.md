# Student-Management-System
The school management system i completed for my system analysis project during 10th semester. The full system connected in a local host database and can store all information in this database.
